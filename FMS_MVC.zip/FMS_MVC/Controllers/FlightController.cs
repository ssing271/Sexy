﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FMS_MVC.Models;

namespace NewMVC.Controllers
{
    public class FlightController : Controller
    {
        private FlightModelEntities db = new FlightModelEntities();

        // GET: Flight_bk
        public ActionResult Index()
        {
            var flight = db.Flight_46004312.Include(f => f.AirportTerminal_46004312).Include(f => f.FlightDeparture_46004312).Include(f => f.FlightStatus_46004312);
            return View(flight.ToList());
        }

        public ActionResult DetailsMenu()
        {
            var flight = db.Flight_46004312.Include(f => f.AirportTerminal_46004312).Include(f => f.FlightDeparture_46004312).Include(f => f.FlightStatus_46004312);
            return View(flight.ToList());
        }

        // GET: Flight_bk/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_46004312 flight_46004312 = db.Flight_46004312.Find(id);
            if (flight_46004312 == null)
            {
                return HttpNotFound();
            }
            return View(flight_46004312);
        }

        // GET: Flight_bk/Create
        public ActionResult Create()
        {
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_46004312, "ID", "TerminalName");
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_46004312, "ID", "ID");
            ViewBag.StatusId = new SelectList(db.FlightStatus_46004312, "ID", "Description");
            return View();
        }


        public ActionResult Viewall()
        {
            var flight = db.Flight_46004312.Include(f => f.AirportTerminal_46004312).Include(f => f.FlightDeparture_46004312).Include(f => f.FlightStatus_46004312);
            return View(flight.ToList());
        }

        // POST: Flight_bk/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Name,Destination,DepartureId,TerminalId,GateNo,StatusId")] Flight_46004312 flight_46004312)
        {
            if (ModelState.IsValid)
            {
                db.Flight_46004312.Add(flight_46004312);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.TerminalId = new SelectList(db.AirportTerminal_46004312, "ID", "TerminalName", flight_46004312.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_46004312, "ID", "ID", flight_46004312.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_46004312, "ID", "Description", flight_46004312.StatusId);
            return View(flight_46004312);
        }

        // GET: Flight_bk/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_46004312 flight_46004312 = db.Flight_46004312.Find(id);
            if (flight_46004312 == null)
            {
                return HttpNotFound();
            }
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_46004312, "ID", "TerminalName", flight_46004312.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_46004312, "ID", "ID", flight_46004312.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_46004312, "ID", "Description", flight_46004312.StatusId);
            return View(flight_46004312);
        }

        // POST: Flight_bk/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Name,Destination,DepartureId,TerminalId,GateNo,StatusId")] Flight_46004312 flight_46004312)
        {
            if (ModelState.IsValid)
            {
                db.Entry(flight_46004312).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_46004312, "ID", "TerminalName", flight_46004312.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_46004312, "ID", "ID", flight_46004312.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_46004312, "ID", "Description", flight_46004312.StatusId);
            return View(flight_46004312);
        }

        // GET: Flight_bk/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_46004312 flight_bk = db.Flight_46004312.Find(id);
            if (flight_bk == null)
            {
                return HttpNotFound();
            }
            return View(flight_bk);
        }

        // POST: Flight_46004312/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Flight_46004312 flight_46004312 = db.Flight_46004312.Find(id);
            db.Flight_46004312.Remove(flight_46004312);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
